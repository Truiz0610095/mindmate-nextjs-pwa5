'use client';
import React, { useState } from 'react';

export default function Page() {
  const [entry, setEntry] = useState('');
  const [response, setResponse] = useState('');
  const [history, setHistory] = useState<{ text: string; mood: string; date: string }[]>([]);
  const [progress, setProgress] = useState(0);

  const analyzeEntry = () => {
    const text = entry.toLowerCase();
    let mood = 'neutral';
    let reply = 'Gracias por compartir. Estoy aquí contigo.';
    if (text.includes('estres') || text.includes('estrés')) {
      mood = 'estresado';
      reply = 'Respira profundo 4-4-4: Inhala 4s, sostén 4s, exhala 4s. 🌿';
    } else if (text.includes('feliz') || text.includes('alegre')) {
      mood = 'feliz';
      reply = '¡Qué alegría! Escribe 3 notas de gratitud ✨';
    } else if (text.includes('triste') || text.includes('decaido') || text.includes('decaído')) {
      mood = 'triste';
      reply = 'Es válido sentirse así. Anota 1 acción pequeña que te haría sentir mejor hoy.';
    } else if (text.includes('ansiedad') || text.includes('ansioso') || text.includes('ansiosa')) {
      mood = 'ansioso';
      reply = 'Prueba la técnica 5-4-3-2-1 para anclarte al presente.';
    }
    setResponse(reply);
    setHistory([{ text: entry, mood, date: new Date().toLocaleString() }, ...history]);
    setProgress(p => Math.min(100, p + 10));
    setEntry('');
  };

  return (
    <main>
      <header style={{ textAlign: 'center', marginBottom: 16 }}>
        <h1 style={{ fontSize: 28, margin: 0 }}>MindMate 🧠</h1>
        <p style={{ marginTop: 8, color: '#334155' }}>Tu compañero emocional impulsado por IA</p>
      </header>

      <section style={{ background: 'white', padding: 12, borderRadius: 12, boxShadow:'0 2px 8px rgba(0,0,0,0.06)' }}>
        <label htmlFor="entry" style={{ display:'block', fontWeight:600, marginBottom: 8 }}>¿Cómo te sientes hoy?</label>
        <textarea
          id="entry"
          placeholder="Escribe libremente..."
          value={entry}
          onChange={(e) => setEntry(e.target.value)}
          style={{ width:'100%', minHeight:120, padding:10, borderRadius:8, border:'1px solid #cbd5e1' }}
        />
        <button
          onClick={analyzeEntry}
          style={{ width:'100%', marginTop: 10, padding:12, borderRadius:10, border:'none', background:'#0ea5e9', color:'white', fontWeight:700 }}
        >
          Analizar con IA (demo)
        </button>
      </section>

      {response && (
        <section style={{ background: 'white', padding: 12, borderRadius: 12, marginTop: 12, boxShadow:'0 2px 8px rgba(0,0,0,0.06)' }}>
          <strong>Respuesta:</strong>
          <p style={{ marginTop: 8 }}>{response}</p>
        </section>
      )}

      <section style={{ background: 'white', padding: 12, borderRadius: 12, marginTop: 12, boxShadow:'0 2px 8px rgba(0,0,0,0.06)' }}>
        <p>Progreso de bienestar: <strong>{progress}%</strong></p>
        <div style={{ width:'100%', height:10, background:'#e2e8f0', borderRadius:8 }}>
          <div style={{ width: progress + '%', height: '100%', background:'#22c55e', borderRadius:8 }} />
        </div>
      </section>

      <section style={{ background: 'white', padding: 12, borderRadius: 12, marginTop: 12, boxShadow:'0 2px 8px rgba(0,0,0,0.06)' }}>
        <h2 style={{ marginTop: 0 }}>Historial</h2>
        {history.length === 0 ? (
          <p style={{ color:'#64748b' }}>Aún no hay entradas.</p>
        ) : (
          <ul style={{ listStyle:'none', padding:0, margin:0 }}>
            {history.map((h, i) => (
              <li key={i} style={{ padding:'8px 0', borderBottom:'1px solid #e2e8f0' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
                  <em style={{ color:'#475569' }}>{h.mood}</em>
                  <span style={{ color:'#94a3b8', fontSize:12 }}>{h.date}</span>
                </div>
                <div style={{ whiteSpace:'pre-wrap', marginTop:4 }}>{h.text}</div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <footer style={{ textAlign:'center', color:'#94a3b8', marginTop: 16, fontSize:12 }}>
        Versión piloto para validación (no clínica).
      </footer>
    </main>
  );
}
