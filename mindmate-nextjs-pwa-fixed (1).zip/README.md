# MindMate – Piloto Next.js (estructura plana)

Proyecto listo para Vercel con Next.js 14 (App Router) y PWA básica.

## Deploy recomendado (GitHub → Vercel)
1. Sube estos archivos **en la raíz** de un repo en GitHub.
2. En Vercel: Add New > Project > Import Git Repository.
3. Deploy (Vercel detecta Next.js).

## Local
npm install
npm run dev
